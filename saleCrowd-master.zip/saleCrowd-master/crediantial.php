<?php
define('EMAIL','hasanbanna006@gmail.com');
define('PASS','B01838241314w');